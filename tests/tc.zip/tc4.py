x=lambda a:1 if a>10 else 0

a=x(11)
b=x(5)
print(a)
print(b)

add=lambda x, y: x+y;
c=add(3,1)
print(c)


## wrong syntax; program should halt and display "error"
l1=[2,3]
l2=[4,5
l3=l1+l2

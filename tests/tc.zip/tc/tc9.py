#long variable name, overwrites previous variable
variable1="hello"
variable2="world"
variable3=variable1+" "+variable2
variable4="Hi,"
variable3=variable4+" "+variable3

print(variable3)

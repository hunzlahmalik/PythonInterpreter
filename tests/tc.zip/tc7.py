list1=[1,2,3]
list2=[4,5,6]
a=list1[2] + list2[2]
b=list1 + list2

str1=["h","e","l","l","o"]
str2=["h","i"]

str3=str1[2]+str2[1]

str4=str1+str2

print(str3)
print(b)
print(str4)

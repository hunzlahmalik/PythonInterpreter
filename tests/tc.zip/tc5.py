lst1=["a","b","c"]
lst2=["r","o","n"]
lst3=lst1[1:]+lst2[0]

print(lst3)


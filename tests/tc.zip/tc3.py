#This testcase test if/else statement
a=12
b=3


if a>b:
  c = 1
else:
  c=0	
print(c)

a=2
b=3
c=a+b
s1="functional"
s2="programming"
s3=s1+" "+ s2
print(c)
print(s3)

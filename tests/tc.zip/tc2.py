l1=[2,3,4]
l2=[4,5,6]
l3=l1+l2
e1=l1[0]
elast=l2[2]
einvalid=l2[4]

var1=45
var2=34
var3=var1+var2

print(e1)
print(elast)
print(l3)
print(var3)

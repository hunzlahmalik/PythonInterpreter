a=5
b=50

if a>=b:
    c=a-b
else:
    c=a-b

print(c)


